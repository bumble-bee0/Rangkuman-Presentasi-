package com.clipvikaitech.rangkumanpresentasi;

import android.content.Context;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;

public class CrashHandler implements Thread.UncaughtExceptionHandler {

    private final Thread.UncaughtExceptionHandler defaultHandler;
    private final File logFile;

    public CrashHandler(Context context, Thread.UncaughtExceptionHandler defaultHandler) {
        this.defaultHandler = defaultHandler;
        this.logFile = new File(context.getFilesDir(), "crash_log.txt");
    }

    @Override
    public void uncaughtException(Thread thread, Throwable ex) {
        try {
            StringWriter sw = new StringWriter();
            ex.printStackTrace(new PrintWriter(sw));
            try (FileWriter fw = new FileWriter(logFile)) {
                fw.write(sw.toString());
            }
        } catch (Exception ignored) {
        }
        if (defaultHandler != null) {
            defaultHandler.uncaughtException(thread, ex);
        }
    }

    public static String readAndClearLog(Context context) {
        File f = new File(context.getFilesDir(), "crash_log.txt");
        if (!f.exists()) return null;
        try {
            StringBuilder sb = new StringBuilder();
            java.util.Scanner sc = new java.util.Scanner(f);
            while (sc.hasNextLine()) {
                sb.append(sc.nextLine()).append("\n");
            }
            sc.close();
            f.delete();
            return sb.toString();
        } catch (Exception e) {
            return "Gagal membaca log crash: " + e;
        }
    }
}
