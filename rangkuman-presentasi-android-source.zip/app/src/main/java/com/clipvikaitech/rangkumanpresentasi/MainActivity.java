package com.clipvikaitech.rangkumanpresentasi;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;
import androidx.webkit.WebViewClientCompat;

public class MainActivity extends AppCompatActivity {

    private static final int MIC_PERMISSION_REQUEST_CODE = 1001;
    private static final String APP_URL = "https://appassets.androidplatform.net/assets/index.html";

    private WebView webView;
    private PermissionRequest pendingWebRequest;
    private AudioBridge audioBridge;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setDatabaseEnabled(true);

        // WebViewAssetLoader melayani file lokal lewat origin https:// palsu
        // (appassets.androidplatform.net) supaya dianggap "secure context" oleh
        // Chromium, dan juga dipakai untuk menyajikan balik file hasil rekaman
        // native dari cache dir ke JavaScript lewat fetch().
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/audio/", new WebViewAssetLoader.InternalStoragePathHandler(this, getCacheDir()))
                .build();

        webView.setWebViewClient(new WebViewClientCompat() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (hasMicPermission()) {
                        request.grant(request.getResources());
                    } else {
                        pendingWebRequest = request;
                        requestMicPermission();
                    }
                });
            }
        });

        // Jembatan Java <-> JavaScript untuk rekam audio pakai MediaRecorder native,
        // dipanggil dari halaman lewat window.AndroidRecorder.startRecording()/stopRecording().
        audioBridge = new AudioBridge(webView, getCacheDir());
        webView.addJavascriptInterface(audioBridge, "AndroidRecorder");

        webView.loadUrl(APP_URL);

        if (!hasMicPermission()) {
            requestMicPermission();
        }
    }

    private boolean hasMicPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                == PackageManager.PERMISSION_GRANTED;
    }

    private void requestMicPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.RECORD_AUDIO},
                MIC_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MIC_PERMISSION_REQUEST_CODE) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            if (granted) {
                if (pendingWebRequest != null) {
                    pendingWebRequest.grant(pendingWebRequest.getResources());
                    pendingWebRequest = null;
                }
            } else {
                Toast.makeText(this, "Izin mikrofon dibutuhkan untuk merekam presentasi.", Toast.LENGTH_LONG).show();
                if (pendingWebRequest != null) {
                    pendingWebRequest.deny();
                    pendingWebRequest = null;
                }
            }
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
