package com.clipvikaitech.rangkumanpresentasi;

import android.media.MediaRecorder;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

import java.io.File;

public class AudioBridge {

    private static final String TAG = "AudioBridge";
    private final WebView webView;
    private final File outputFile;
    private MediaRecorder recorder;

    public AudioBridge(WebView webView, File cacheDir) {
        this.webView = webView;
        this.outputFile = new File(cacheDir, "recording.m4a");
    }

    @JavascriptInterface
    public void startRecording() {
        try {
            if (outputFile.exists()) {
                outputFile.delete();
            }
            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            recorder.setAudioEncodingBitRate(96000);
            recorder.setAudioSamplingRate(44100);
            recorder.setOutputFile(outputFile.getAbsolutePath());
            recorder.prepare();
            recorder.start();
        } catch (Exception e) {
            Log.e(TAG, "startRecording gagal", e);
            notifyError(e.toString());
            releaseRecorder();
        }
    }

    @JavascriptInterface
    public void stopRecording() {
        try {
            if (recorder == null) {
                notifyError("Recorder belum dimulai.");
                return;
            }
            recorder.stop();
            releaseRecorder();
            runOnWebView("window.onNativeRecordingReady && window.onNativeRecordingReady();");
        } catch (Exception e) {
            Log.e(TAG, "stopRecording gagal", e);
            notifyError(e.toString());
            releaseRecorder();
        }
    }

    @JavascriptInterface
    public void cancelRecording() {
        releaseRecorder();
        if (outputFile.exists()) {
            outputFile.delete();
        }
    }

    private void releaseRecorder() {
        if (recorder != null) {
            try {
                recorder.reset();
                recorder.release();
            } catch (Exception ignored) {
            }
            recorder = null;
        }
    }

    private void notifyError(String message) {
        String safe = JSONObject.quote(message);
        runOnWebView("window.onNativeRecordingError && window.onNativeRecordingError(" + safe + ");");
    }

    private void runOnWebView(String js) {
        webView.post(() -> webView.evaluateJavascript(js, null));
    }
}
